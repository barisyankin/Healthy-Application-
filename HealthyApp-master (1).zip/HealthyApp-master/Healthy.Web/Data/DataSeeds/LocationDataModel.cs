﻿using Newtonsoft.Json;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace Healthy.Web.Data.DataSeeds
{
    public class LocationDataModel
    {
        [JsonProperty("ProvinceName")]
        public string ProvinceName { get; set; }
        [JsonProperty("Districts")]
        public List<District> Districts { get; set; }
    }

    public class District
    {
        [JsonProperty("DistrictName")]
        public string DistrictName { get; set; }
    }
}
