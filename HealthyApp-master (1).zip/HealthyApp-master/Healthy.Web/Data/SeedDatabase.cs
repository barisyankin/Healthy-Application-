﻿using FizzWare.NBuilder;
using Healthy.Entities.Concrete;
using Healthy.Entities.Concrete.Identity;
using Healthy.Web.Concrete.Context;
using Healthy.Web.Data.DataSeeds;
using Microsoft.AspNetCore.Hosting;
using Microsoft.AspNetCore.Identity;
using Newtonsoft.Json;
using System;
using System.Collections.Generic;
using System.IO;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Healthy.Web.Data
{
    public static class SeedDatabase
    {
        public static async Task CreateRoles(RoleManager<IdentityRole> roleManager)
        {
            var customerRoleExists = await roleManager.RoleExistsAsync("customer");
            var trainerRoleExists = await roleManager.RoleExistsAsync("trainer");

            if (customerRoleExists || trainerRoleExists)
                throw new Exception("Roles exist!");

            var customerRoleResult = await roleManager.CreateAsync(new IdentityRole("customer"));
            var trainerRoleResult = await roleManager.CreateAsync(new IdentityRole("trainer"));

            if (!customerRoleResult.Succeeded || !trainerRoleResult.Succeeded)
                throw new Exception("Cannot create roles!");

        }
        public static async Task SeedLocation(HealthyContext _context)
        {
            var projectRoot = Directory.GetCurrentDirectory();
            var locationJsonPath = Path.Combine(projectRoot, @"Data\DataSeeds\location-seed.json");

            Encoding.RegisterProvider(CodePagesEncodingProvider.Instance);
            using (StreamReader reader = new StreamReader(locationJsonPath, Encoding.GetEncoding("iso-8859-9")))
            {
                string json = await reader.ReadToEndAsync();

                List<LocationDataModel> items = JsonConvert.DeserializeObject<List<LocationDataModel>>(json);

                items.ForEach(item =>
                {
                    var province = new Province
                    {
                        Name = item.ProvinceName
                    };
                    _context.Provinces.Add(province);
                    _context.SaveChanges();

                    item.Districts.ForEach(d =>
                    {
                        var district = new Entities.Concrete.District
                        {
                            Name = d.DistrictName,
                            ProvinceId = province.Id,
                        };

                        _context.Districts.Add(district);
                        _context.SaveChanges();
                    });
                });
            }
        }


        public static async Task SeedUsers(HealthyContext context, UserManager<HealthyUser> userManager, IWebHostEnvironment _env)
        {
            var customers = Builder<HealthyUser>.CreateListOfSize(50)
               .All()
                   .With(c => c.Name = Faker.Name.First())
                   .With(c => c.Surname = Faker.Name.Last())
                   .With(c => c.Email = Faker.Internet.Email(c.Name))
                   .With(c => c.UserName = c.Email)
                   .With(c => c.PhoneNumber = Faker.Phone.Number())
                   .With(c => c.EmailConfirmed = true)
                   .With(c => c.DistrictId == null)
                   .With(c => c.TrainerProfileId == null)
                   .With(c => c.IsTrainer = false)
                   .With(c => c.TwoFactorEnabled = false)
               .Build();

            var trainers = Builder<HealthyUser>.CreateListOfSize(50)
               .All()
                   .With(c => c.Name = Faker.Name.First())
                   .With(c => c.Surname = Faker.Name.Last())
                   .With(c => c.Email = Faker.Internet.Email(c.Name))
                   .With(c => c.UserName = c.Email)
                   .With(c => c.PhoneNumber = Faker.Phone.Number())
                   .With(c => c.EmailConfirmed = true)
                   .With(c => c.DistrictId == null)
                   .With(c => c.TrainerProfileId == null)
                   .With(c => c.IsTrainer = true)
                   .With(c => c.TwoFactorEnabled = false)
               .Build();

            foreach (var customer in customers)
            {
                var randomDistrict = context.Districts.OrderBy(r => Guid.NewGuid()).Take(1).First();

                customer.DistrictId = randomDistrict.Id;
                customer.TrainerProfileId = null;

                var password = "Burak100?";
                var result = await userManager.CreateAsync(customer, password);

                if (!customer.IsTrainer)
                {
                    var randomGenerator = new RandomGenerator();

                    var bodyInformation = new UserBodyInformation
                    {
                        Age = randomGenerator.Next(20, 60),
                        Basin = randomGenerator.Next(120, 160),
                        Biceps = randomGenerator.Next(50, 70),
                        Chest = randomGenerator.Next(50, 90),
                        Height = randomGenerator.Next(155, 195),
                        InnerLegLength = randomGenerator.Next(80, 150),
                        OuterLegLength = randomGenerator.Next(80, 150),
                        ShoulderWidth = randomGenerator.Next(100, 150),
                        Waist = randomGenerator.Next(50, 120),
                        Triceps = randomGenerator.Next(50, 70),
                        Weight = randomGenerator.Next(45, 135),
                        FatRate = randomGenerator.Next(5, 25),
                        HealthyUserId = customer.Id                        
                    };

                    context.UserBodyInformations.Add(bodyInformation);
                    context.SaveChanges();

                    customer.UserBodyInformationId = bodyInformation.Id;
                    await userManager.UpdateAsync(customer);
                }

                if (!result.Succeeded)
                    throw new Exception("Cannot create user");

                await userManager.AddToRoleAsync(customer, "customer");
            }

            foreach (var trainer in trainers)
            {
                var randomDistrict = context.Districts.OrderBy(r => Guid.NewGuid()).Take(1).First();

                trainer.DistrictId = randomDistrict.Id;
                trainer.TrainerProfileId = null;

                var password = "Burak100?";
                var result = await userManager.CreateAsync(trainer, password);

                if (!result.Succeeded)
                    throw new Exception("Cannot create user");

                await userManager.AddToRoleAsync(trainer, "trainer");

                if (trainer.IsTrainer)
                {
                    var priceGenerator = new RandomGenerator();

                    var profile = new TrainerProfile
                    {
                        Title = Faker.Lorem.Sentence(2),
                        AboutMe = Faker.Lorem.Paragraph(150),
                        PerLessonPrice = Convert.ToDouble(priceGenerator.Next(49.99, 499.99)),
                        TrainerId = trainer.Id
                    };

                    context.TrainerProfiles.Add(profile);
                    context.SaveChanges();

                    trainer.TrainerProfileId = profile.Id;
                    await userManager.UpdateAsync(trainer);

                    var rn = priceGenerator.Next(1, 4);
                    var path = Path.Combine(_env.WebRootPath, "usercertificates");
                    var filePaths = Directory.GetFiles(path);

                    var certificateFilesPaths = filePaths.OrderBy(r => Guid.NewGuid()).Take(rn).ToList();

                    foreach (var filePath in certificateFilesPaths)
                    {
                        var certificate = new UserCertificates
                        {
                            CertificateName = trainer.Name + "_Certificate",
                            FilePath = Path.GetFileName(filePath),
                            HealthyUserId = trainer.Id
                        };

                        context.UserCertificates.Add(certificate);
                        context.SaveChanges();
                    }
                }
            }
        }
    }
}
