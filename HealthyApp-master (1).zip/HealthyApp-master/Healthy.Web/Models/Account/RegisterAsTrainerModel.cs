﻿using Healthy.Entities.Concrete.Identity;
using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Mvc.Rendering;
using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;
using System.Linq;

namespace Healthy.Web.Models.Account
{
    public class RegisterAsTrainerModel
    {        
        [Required(ErrorMessage = "Username field cannot be empty!")]
        [StringLength(20, ErrorMessage = "Username field cannot exceed 20 characters!")]
        [RegularExpression(@"^\S*$", ErrorMessage = "Username field cannot contain whitespace characters!")]
        public string Username { get; set; }

        [Required(ErrorMessage = "Email field cannot be empty!")]
        [DataType(DataType.EmailAddress)]
        public string Email { get; set; }

        [Required(ErrorMessage = "Name field cannot be empty!")]
        [StringLength(30, ErrorMessage = "Name field cannot exceed 30 characters!")]
        public string Name { get; set; }

        [Required(ErrorMessage = "Surname field cannot be empty!")]
        [StringLength(30, ErrorMessage = "Surname field cannot exceed 30 characters!")]
        public string Surname { get; set; }

        [Required(ErrorMessage = "Phone number field cannot be empty!")]
        [DataType(DataType.PhoneNumber)]
        public string PhoneNumber { get; set; }

        [Required(ErrorMessage = "Password field cannot be empty!")]
        [StringLength(50, MinimumLength = 8, ErrorMessage = "Password field should be 8-50 characters logn!")]
        [DataType(DataType.Password)]
        public string Password { get; set; }

        [Required(ErrorMessage = "Confirm password field cannot be empty!")]
        [DataType(DataType.Password)]
        [Compare(nameof(Password))]
        public string ConfirmPassword { get; set; }

        [Required(ErrorMessage = "Please select your location!")]
        public int? DistrictId { get; set; }

        [Required(ErrorMessage = "Please select an environment!")]
        public int? TrainingEnvironment { get; set; }

        [Required(ErrorMessage = "You have to choose at least 1 certificate file!")]
        public IFormFile[] Certificates { get; set; }        


        public RegisterAsTrainerModel()
        {
            TrainingEnvironmentSelectList = new SelectList(Enum.GetValues(typeof(TrainingEnvironment))
                                                      .Cast<TrainingEnvironment>()
                                                      .Select(v => new SelectListItem
                                                      {
                                                          Text = v.ToString(),
                                                          Value = ((int)v).ToString()
                                                      }).ToList(), "Value", "Text");
        }
        public SelectList TrainingEnvironmentSelectList { get; set; }
    }
}
