﻿using Newtonsoft.Json;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace Healthy.Web.Models.Account
{
    public class LocationJsonData
    {
        [JsonProperty("value")]
        public int Value { get; set; }
        [JsonProperty("attributes")]
        public LocationAttributeData Attributes { get; set; }
    }

    public class LocationAttributeData
    {
        [JsonProperty("province")]
        public string Province { get; set; }
        [JsonProperty("district")]
        public string District { get; set; }
    }
}
