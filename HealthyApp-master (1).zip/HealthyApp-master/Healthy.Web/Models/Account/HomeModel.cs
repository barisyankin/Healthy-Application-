﻿using Healthy.Entities.Concrete.Identity;
using Microsoft.AspNetCore.Mvc.Rendering;
using Newtonsoft.Json;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace Healthy.Web.Models.Account
{
    public class HomeModel
    {
        public HomeModel()
        {
            TrainingEnvironmentSelectList = new SelectList(Enum.GetValues(typeof(TrainingEnvironment))
                                                      .Cast<TrainingEnvironment>()
                                                      .Select(v => new SelectListItem
                                                      {
                                                          Text = v.ToString(),
                                                          Value = ((int)v).ToString()
                                                      }).ToList(), "Value", "Text");
        }

        public SelectList TrainingEnvironmentSelectList { get; set; }
        public bool HasCurrentlyActiveMatch { get; set; }
        public List<TrainingGoal> TrainingGoals { get; set; }
        public List<TrainingGoal> SelectedTrainingGoals { get; set; }
        public List<HealthyUser> FoundTrainers { get; set; }
        public int UserTrainerMatchId { get; set; }
        public List<HealthyUser> CurrentTrainerCustomers { get; set; }
        public string TrainerId { get; set; }

        //Form Inputs
        public int TrainingEnvironment { get; set; }
        
        public int DistrictId { get; set; }
        
        public int[] TraningGoalFilters { get; set; }
    }
}
