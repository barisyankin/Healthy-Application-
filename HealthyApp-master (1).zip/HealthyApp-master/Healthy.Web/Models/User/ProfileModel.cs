﻿using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;
using System.Linq;
using System.Threading.Tasks;

namespace Healthy.Web.Models.User
{
    public class ProfileModel
    {
        [Required(ErrorMessage = "Name field cannot be empty!")]
        public string Name { get; set; }

        [Required(ErrorMessage = "Surname field cannot be empty!")]
        public string Surname { get; set; }

        public string Email { get; set; }

        [Required(ErrorMessage = "Age field cannot be empty!")]
        public int Age { get; set; }

        [Required(ErrorMessage = "Height field cannot be empty!")]
        public int Height { get; set; }

        [Required(ErrorMessage = "Weight field cannot be empty!")]
        public int Weight { get; set; }

        [Required(ErrorMessage = "Outer Leg Length field cannot be empty!")]
        public int OuterLegLength { get; set; }

        [Required(ErrorMessage = "Inner Leg Length field cannot be empty!")]
        public int InnerLegLength { get; set; }

        [Required(ErrorMessage = "Chest field cannot be empty!")]
        public int Chest { get; set; }

        [Required(ErrorMessage = "Waist field cannot be empty!")]
        public int Waist { get; set; }

        [Required(ErrorMessage = "Basin field cannot be empty!")]
        public int Basin { get; set; }

        [Required(ErrorMessage = "Shoulder Width field cannot be empty!")]
        public int ShoulderWidth { get; set; }

        [Required(ErrorMessage = "Triceps field cannot be empty!")]
        public int Triceps { get; set; }

        [Required(ErrorMessage = "Biceps field cannot be empty!")]
        public int Biceps { get; set; }

        [Required(ErrorMessage = "FatRate field cannot be empty!")]
        public int FatRate { get; set; }
    }
}
