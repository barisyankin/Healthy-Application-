﻿using Healthy.Entities.Concrete;
using Healthy.Entities.Concrete.Identity;
using Microsoft.AspNetCore.Identity.EntityFrameworkCore;
using Microsoft.EntityFrameworkCore;

namespace Healthy.Web.Concrete.Context
{
    public class HealthyContext : IdentityDbContext<HealthyUser>
    {
        public HealthyContext()
        {

        }
        public HealthyContext(DbContextOptions<HealthyContext> options)
            : base(options)
        {

        }


        public DbSet<Province> Provinces { get; set; }
        public DbSet<District> Districts { get; set; }

        public DbSet<UserCertificates> UserCertificates { get; set; }
        public DbSet<UserBodyInformation> UserBodyInformations { get; set; }

        public DbSet<UserTrainerMatch> UserTrainerMatchs { get; set; }
        public DbSet<UserTrainerMessage> UserTrainerMessages { get; set; }

        public DbSet<TrainingGoal> TrainingGoal { get; set; }
        public DbSet<UserTrainingGoal> UserTrainingGoal { get; set; }
        public DbSet<UserTrainerMatchForm> UserTrainerMatchForm { get; set; }
        public DbSet<TrainerTrainingGoal> TrainerTrainingGoals { get; set; }

        public DbSet<TrainerProfile> TrainerProfiles { get; set; }

        protected override void OnModelCreating(ModelBuilder builder)
        {
            builder.Entity<Province>().HasMany(x => x.Districts).WithOne(x => x.Province).HasForeignKey(x => x.ProvinceId).OnDelete(DeleteBehavior.Cascade);

            builder.Entity<HealthyUser>().HasMany(x => x.UserCertificates).WithOne(x => x.HealthyUser).HasForeignKey(x => x.HealthyUserId).OnDelete(DeleteBehavior.Cascade);

            builder.Entity<District>().HasMany(x => x.HealthyUsers).WithOne(x => x.District).HasForeignKey(x => x.DistrictId);

            builder.Entity<HealthyUser>().HasMany(x => x.UserMatchs).WithOne(x => x.User).HasForeignKey(x => x.UserId);
            builder.Entity<HealthyUser>().HasMany(x => x.TrainerMatchs).WithOne(x => x.Trainer).HasForeignKey(x => x.TrainerId);

            builder.Entity<UserTrainerMatch>().HasMany(x => x.UserTrainerMessages).WithOne(x => x.UserTrainerMatch).HasForeignKey(x => x.UserTrainerMatchId).OnDelete(DeleteBehavior.Cascade);
            
            builder.Entity<HealthyUser>().HasMany(x => x.UserTrainerMessages).WithOne(x => x.Sender).HasForeignKey(x => x.SenderId).OnDelete(DeleteBehavior.Cascade);
            
            builder.Entity<HealthyUser>().HasMany(x => x.UserTrainerMatchForms).WithOne(x => x.HealthyUser).HasForeignKey(x => x.HealthyUserId).OnDelete(DeleteBehavior.Cascade);
            builder.Entity<District>().HasMany(x => x.UserTrainerMatchForms).WithOne(x => x.District).HasForeignKey(x => x.DistrictId);

            builder.Entity<UserTrainingGoal>().HasKey(x => new { x.HealthyUserId, x.TrainingGoalId });
            builder.Entity<TrainerTrainingGoal>().HasKey(x => new { x.HealthyUserId, x.TrainingGoalId });

            builder.Entity<HealthyUser>().HasOne(x => x.TrainerProfile).WithOne(x => x.Trainer).HasForeignKey<TrainerProfile>(x => x.TrainerId);
            builder.Entity<HealthyUser>().HasOne(x => x.UserBodyInformation).WithOne(x => x.HealthyUser).HasForeignKey<UserBodyInformation>(x => x.HealthyUserId);

            base.OnModelCreating(builder);
        }
    }
}


