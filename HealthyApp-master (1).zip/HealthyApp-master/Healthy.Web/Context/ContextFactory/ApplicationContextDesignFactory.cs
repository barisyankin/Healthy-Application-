﻿using Healthy.Web.Concrete.Context;
using Healthy.Web.Context.ContextFactory;
using Microsoft.EntityFrameworkCore;
using System.Reflection;

namespace Healthy.Web.Concrete.EF.Context.ContextFactory
{
    public class ApplicationContextDesignFactory : DesignTimeDbContextFactoryBase<HealthyContext>
    {
        public ApplicationContextDesignFactory() : base("HealthyConnection", typeof(ApplicationContextDesignFactory).GetTypeInfo().Assembly.GetName().Name)
        { }
        protected override HealthyContext CreateNewInstance(DbContextOptions<HealthyContext> options)
        {
            return new HealthyContext(options);
        }
    }
}
