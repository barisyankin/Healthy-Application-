﻿using Microsoft.EntityFrameworkCore.Migrations;

namespace Healthy.Web.Migrations
{
    public partial class Deletes_NeighboorHood_Adds_Distrcit : Migration
    {
        protected override void Up(MigrationBuilder migrationBuilder)
        {
            migrationBuilder.DropForeignKey(
                name: "FK_AspNetUsers_Neighborhoods_NeighborhoodId",
                table: "AspNetUsers");

            migrationBuilder.DropTable(
                name: "Neighborhoods");

            migrationBuilder.RenameColumn(
                name: "NeighborhoodId",
                table: "AspNetUsers",
                newName: "DistrictId");

            migrationBuilder.RenameIndex(
                name: "IX_AspNetUsers_NeighborhoodId",
                table: "AspNetUsers",
                newName: "IX_AspNetUsers_DistrictId");

            migrationBuilder.AddForeignKey(
                name: "FK_AspNetUsers_Districts_DistrictId",
                table: "AspNetUsers",
                column: "DistrictId",
                principalTable: "Districts",
                principalColumn: "Id",
                onDelete: ReferentialAction.Restrict);
        }

        protected override void Down(MigrationBuilder migrationBuilder)
        {
            migrationBuilder.DropForeignKey(
                name: "FK_AspNetUsers_Districts_DistrictId",
                table: "AspNetUsers");

            migrationBuilder.RenameColumn(
                name: "DistrictId",
                table: "AspNetUsers",
                newName: "NeighborhoodId");

            migrationBuilder.RenameIndex(
                name: "IX_AspNetUsers_DistrictId",
                table: "AspNetUsers",
                newName: "IX_AspNetUsers_NeighborhoodId");

            migrationBuilder.CreateTable(
                name: "Neighborhoods",
                columns: table => new
                {
                    Id = table.Column<int>(type: "int", nullable: false)
                        .Annotation("SqlServer:Identity", "1, 1"),
                    DistrictId = table.Column<int>(type: "int", nullable: false),
                    Name = table.Column<string>(type: "nvarchar(max)", nullable: true)
                },
                constraints: table =>
                {
                    table.PrimaryKey("PK_Neighborhoods", x => x.Id);
                    table.ForeignKey(
                        name: "FK_Neighborhoods_Districts_DistrictId",
                        column: x => x.DistrictId,
                        principalTable: "Districts",
                        principalColumn: "Id",
                        onDelete: ReferentialAction.Cascade);
                });

            migrationBuilder.CreateIndex(
                name: "IX_Neighborhoods_DistrictId",
                table: "Neighborhoods",
                column: "DistrictId");

            migrationBuilder.AddForeignKey(
                name: "FK_AspNetUsers_Neighborhoods_NeighborhoodId",
                table: "AspNetUsers",
                column: "NeighborhoodId",
                principalTable: "Neighborhoods",
                principalColumn: "Id",
                onDelete: ReferentialAction.Restrict);
        }
    }
}
