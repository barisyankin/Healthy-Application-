﻿using Microsoft.EntityFrameworkCore.Migrations;

namespace Healthy.Web.Migrations
{
    public partial class Changes_1N_to_1T1 : Migration
    {
        protected override void Up(MigrationBuilder migrationBuilder)
        {
            migrationBuilder.DropForeignKey(
                name: "FK_UserBodyInformations_AspNetUsers_HealthyUserId",
                table: "UserBodyInformations");

            migrationBuilder.DropIndex(
                name: "IX_UserBodyInformations_HealthyUserId",
                table: "UserBodyInformations");

            migrationBuilder.AddColumn<int>(
                name: "UserBodyInformationId",
                table: "AspNetUsers",
                type: "int",
                nullable: true);

            migrationBuilder.CreateIndex(
                name: "IX_UserBodyInformations_HealthyUserId",
                table: "UserBodyInformations",
                column: "HealthyUserId",
                unique: true,
                filter: "[HealthyUserId] IS NOT NULL");

            migrationBuilder.AddForeignKey(
                name: "FK_UserBodyInformations_AspNetUsers_HealthyUserId",
                table: "UserBodyInformations",
                column: "HealthyUserId",
                principalTable: "AspNetUsers",
                principalColumn: "Id",
                onDelete: ReferentialAction.Restrict);
        }

        protected override void Down(MigrationBuilder migrationBuilder)
        {
            migrationBuilder.DropForeignKey(
                name: "FK_UserBodyInformations_AspNetUsers_HealthyUserId",
                table: "UserBodyInformations");

            migrationBuilder.DropIndex(
                name: "IX_UserBodyInformations_HealthyUserId",
                table: "UserBodyInformations");

            migrationBuilder.DropColumn(
                name: "UserBodyInformationId",
                table: "AspNetUsers");

            migrationBuilder.CreateIndex(
                name: "IX_UserBodyInformations_HealthyUserId",
                table: "UserBodyInformations",
                column: "HealthyUserId");

            migrationBuilder.AddForeignKey(
                name: "FK_UserBodyInformations_AspNetUsers_HealthyUserId",
                table: "UserBodyInformations",
                column: "HealthyUserId",
                principalTable: "AspNetUsers",
                principalColumn: "Id",
                onDelete: ReferentialAction.Cascade);
        }
    }
}
