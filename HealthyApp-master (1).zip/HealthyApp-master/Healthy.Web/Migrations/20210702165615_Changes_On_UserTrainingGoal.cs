﻿using Microsoft.EntityFrameworkCore.Migrations;

namespace Healthy.Web.Migrations
{
    public partial class Changes_On_UserTrainingGoal : Migration
    {
        protected override void Up(MigrationBuilder migrationBuilder)
        {
            migrationBuilder.DropForeignKey(
                name: "FK_UserTrainingGoal_UserTrainerMatchForm_UserTrainerMatchFormId",
                table: "UserTrainingGoal");

            migrationBuilder.DropPrimaryKey(
                name: "PK_UserTrainingGoal",
                table: "UserTrainingGoal");

            migrationBuilder.DropColumn(
                name: "UserTrainerMatchFormId",
                table: "UserTrainingGoal");

            migrationBuilder.AddColumn<string>(
                name: "HealthyUserId",
                table: "UserTrainingGoal",
                type: "nvarchar(450)",
                nullable: false,
                defaultValue: "");

            migrationBuilder.AddPrimaryKey(
                name: "PK_UserTrainingGoal",
                table: "UserTrainingGoal",
                columns: new[] { "HealthyUserId", "TrainingGoalId" });

            migrationBuilder.AddForeignKey(
                name: "FK_UserTrainingGoal_AspNetUsers_HealthyUserId",
                table: "UserTrainingGoal",
                column: "HealthyUserId",
                principalTable: "AspNetUsers",
                principalColumn: "Id",
                onDelete: ReferentialAction.Cascade);
        }

        protected override void Down(MigrationBuilder migrationBuilder)
        {
            migrationBuilder.DropForeignKey(
                name: "FK_UserTrainingGoal_AspNetUsers_HealthyUserId",
                table: "UserTrainingGoal");

            migrationBuilder.DropPrimaryKey(
                name: "PK_UserTrainingGoal",
                table: "UserTrainingGoal");

            migrationBuilder.DropColumn(
                name: "HealthyUserId",
                table: "UserTrainingGoal");

            migrationBuilder.AddColumn<int>(
                name: "UserTrainerMatchFormId",
                table: "UserTrainingGoal",
                type: "int",
                nullable: false,
                defaultValue: 0);

            migrationBuilder.AddPrimaryKey(
                name: "PK_UserTrainingGoal",
                table: "UserTrainingGoal",
                columns: new[] { "UserTrainerMatchFormId", "TrainingGoalId" });

            migrationBuilder.AddForeignKey(
                name: "FK_UserTrainingGoal_UserTrainerMatchForm_UserTrainerMatchFormId",
                table: "UserTrainingGoal",
                column: "UserTrainerMatchFormId",
                principalTable: "UserTrainerMatchForm",
                principalColumn: "Id",
                onDelete: ReferentialAction.Cascade);
        }
    }
}
