﻿using Microsoft.EntityFrameworkCore.Migrations;

namespace Healthy.Web.Migrations
{
    public partial class Adds_TrainerTrainingGoals : Migration
    {
        protected override void Up(MigrationBuilder migrationBuilder)
        {
            migrationBuilder.CreateTable(
                name: "TrainerTrainingGoals",
                columns: table => new
                {
                    HealthyUserId = table.Column<string>(type: "nvarchar(450)", nullable: false),
                    TrainingGoalId = table.Column<int>(type: "int", nullable: false)
                },
                constraints: table =>
                {
                    table.PrimaryKey("PK_TrainerTrainingGoals", x => new { x.HealthyUserId, x.TrainingGoalId });
                    table.ForeignKey(
                        name: "FK_TrainerTrainingGoals_AspNetUsers_HealthyUserId",
                        column: x => x.HealthyUserId,
                        principalTable: "AspNetUsers",
                        principalColumn: "Id",
                        onDelete: ReferentialAction.Cascade);
                    table.ForeignKey(
                        name: "FK_TrainerTrainingGoals_TrainingGoal_TrainingGoalId",
                        column: x => x.TrainingGoalId,
                        principalTable: "TrainingGoal",
                        principalColumn: "Id",
                        onDelete: ReferentialAction.Cascade);
                });

            migrationBuilder.CreateIndex(
                name: "IX_TrainerTrainingGoals_TrainingGoalId",
                table: "TrainerTrainingGoals",
                column: "TrainingGoalId");
        }

        protected override void Down(MigrationBuilder migrationBuilder)
        {
            migrationBuilder.DropTable(
                name: "TrainerTrainingGoals");
        }
    }
}
