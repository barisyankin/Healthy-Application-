﻿using Microsoft.EntityFrameworkCore.Migrations;

namespace Healthy.Web.Migrations
{
    public partial class Adds_UserTrainerMatchForm : Migration
    {
        protected override void Up(MigrationBuilder migrationBuilder)
        {
            migrationBuilder.CreateTable(
                name: "TrainingGoal",
                columns: table => new
                {
                    Id = table.Column<int>(type: "int", nullable: false)
                        .Annotation("SqlServer:Identity", "1, 1"),
                    Goal = table.Column<string>(type: "nvarchar(max)", nullable: true)
                },
                constraints: table =>
                {
                    table.PrimaryKey("PK_TrainingGoal", x => x.Id);
                });

            migrationBuilder.CreateTable(
                name: "UserTrainerMatchForm",
                columns: table => new
                {
                    Id = table.Column<int>(type: "int", nullable: false)
                        .Annotation("SqlServer:Identity", "1, 1"),
                    HealthyUserId = table.Column<string>(type: "nvarchar(450)", nullable: true),
                    DistrictId = table.Column<int>(type: "int", nullable: false),
                    TrainingEnvironment = table.Column<int>(type: "int", nullable: false)
                },
                constraints: table =>
                {
                    table.PrimaryKey("PK_UserTrainerMatchForm", x => x.Id);
                    table.ForeignKey(
                        name: "FK_UserTrainerMatchForm_AspNetUsers_HealthyUserId",
                        column: x => x.HealthyUserId,
                        principalTable: "AspNetUsers",
                        principalColumn: "Id",
                        onDelete: ReferentialAction.Cascade);
                    table.ForeignKey(
                        name: "FK_UserTrainerMatchForm_Districts_DistrictId",
                        column: x => x.DistrictId,
                        principalTable: "Districts",
                        principalColumn: "Id",
                        onDelete: ReferentialAction.Cascade);
                });

            migrationBuilder.CreateTable(
                name: "UserTrainingGoal",
                columns: table => new
                {
                    UserTrainerMatchFormId = table.Column<int>(type: "int", nullable: false),
                    TrainingGoalId = table.Column<int>(type: "int", nullable: false)
                },
                constraints: table =>
                {
                    table.PrimaryKey("PK_UserTrainingGoal", x => new { x.UserTrainerMatchFormId, x.TrainingGoalId });
                    table.ForeignKey(
                        name: "FK_UserTrainingGoal_TrainingGoal_TrainingGoalId",
                        column: x => x.TrainingGoalId,
                        principalTable: "TrainingGoal",
                        principalColumn: "Id",
                        onDelete: ReferentialAction.Cascade);
                    table.ForeignKey(
                        name: "FK_UserTrainingGoal_UserTrainerMatchForm_UserTrainerMatchFormId",
                        column: x => x.UserTrainerMatchFormId,
                        principalTable: "UserTrainerMatchForm",
                        principalColumn: "Id",
                        onDelete: ReferentialAction.Cascade);
                });

            migrationBuilder.CreateIndex(
                name: "IX_UserTrainerMatchForm_DistrictId",
                table: "UserTrainerMatchForm",
                column: "DistrictId");

            migrationBuilder.CreateIndex(
                name: "IX_UserTrainerMatchForm_HealthyUserId",
                table: "UserTrainerMatchForm",
                column: "HealthyUserId");

            migrationBuilder.CreateIndex(
                name: "IX_UserTrainingGoal_TrainingGoalId",
                table: "UserTrainingGoal",
                column: "TrainingGoalId");
        }

        protected override void Down(MigrationBuilder migrationBuilder)
        {
            migrationBuilder.DropTable(
                name: "UserTrainingGoal");

            migrationBuilder.DropTable(
                name: "TrainingGoal");

            migrationBuilder.DropTable(
                name: "UserTrainerMatchForm");
        }
    }
}
