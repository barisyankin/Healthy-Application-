﻿using Healthy.Entities.Concrete.Identity;
using Healthy.Web.Concrete.Context;
using Healthy.Web.Models.User;
using Microsoft.AspNetCore.Authorization;
using Microsoft.AspNetCore.Identity;
using Microsoft.AspNetCore.Mvc;
using Microsoft.EntityFrameworkCore;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace Healthy.Web.Controllers
{
    [Authorize()]
    public class UserController : Controller
    {
        private readonly UserManager<HealthyUser> _userManager;
        private readonly HealthyContext _context;
        public UserController(UserManager<HealthyUser> userManager, HealthyContext context)
        {
            _userManager = userManager;
            _context = context;
        }

        private Task<HealthyUser> GetCurrentUserAsync() => _userManager.GetUserAsync(HttpContext.User);

        public async Task<IActionResult> Profile()
        {
            ViewBag.UpdateSuccess = TempData["UpdateSuccess"];

            var currentUser = await GetCurrentUserAsync();

            var user = _context.Users
                .Include(x => x.UserBodyInformation)
                .Single(x => x.Id == currentUser.Id);

            if (user.UserBodyInformation != null)
            {
                var model = new ProfileModel
                {
                    Name = user.Name,
                    Surname = user.Surname,
                    Email = user.Email,
                    Age = user.UserBodyInformation.Age,
                    Basin = user.UserBodyInformation.Basin,
                    Biceps = user.UserBodyInformation.Biceps,
                    Chest = user.UserBodyInformation.Chest,
                    FatRate = user.UserBodyInformation.FatRate,
                    Height = user.UserBodyInformation.Height,
                    InnerLegLength = user.UserBodyInformation.InnerLegLength,
                    OuterLegLength = user.UserBodyInformation.OuterLegLength,
                    ShoulderWidth = user.UserBodyInformation.ShoulderWidth,
                    Triceps = user.UserBodyInformation.Triceps,
                    Waist = user.UserBodyInformation.Waist,
                    Weight = user.UserBodyInformation.Weight
                };
                return View(model);
            }
            else
            {
                var model = new ProfileModel
                {
                    Name = user.Name,
                    Surname = user.Surname,
                    Email = user.Email
                };
                return View(model);
            }
        }

        [HttpPost]
        public async Task<IActionResult> Profile(ProfileModel model)
        {
            if (!ModelState.IsValid)
            {
                var returnModel = new ProfileModel
                {
                    Name = model.Name,
                    Surname = model.Surname,
                    Email = model.Email,
                    Age = model.Age,
                    Basin = model.Basin,
                    Biceps = model.Biceps,
                    Chest = model.Chest,
                    FatRate = model.FatRate,
                    Height = model.Height,
                    InnerLegLength = model.InnerLegLength,
                    OuterLegLength = model.OuterLegLength,
                    ShoulderWidth = model.ShoulderWidth,
                    Triceps = model.Triceps,
                    Waist = model.Waist,
                    Weight = model.Weight
                };
                return View(returnModel);
            }

            var user = await GetCurrentUserAsync();

            user.Name = model.Name;
            user.Surname = model.Surname;

            await _userManager.UpdateAsync(user);

            var userBodyInfo = _context.UserBodyInformations.FirstOrDefault(x => x.Id == user.UserBodyInformationId);

            if (userBodyInfo == null)
            {
                userBodyInfo = new UserBodyInformation
                {
                    Age = model.Age,
                    Basin = model.Basin,
                    Biceps = model.Biceps,
                    Chest = model.Chest,
                    FatRate = model.FatRate,
                    Height = model.Height,
                    InnerLegLength = model.InnerLegLength,
                    OuterLegLength = model.OuterLegLength,
                    ShoulderWidth = model.ShoulderWidth,
                    Triceps = model.Triceps,
                    Waist = model.Waist,
                    Weight = model.Weight,
                    HealthyUserId = user.Id
                };

                _context.UserBodyInformations.Add(userBodyInfo);
                _context.SaveChanges();

                user.UserBodyInformationId = userBodyInfo.Id;

                await _userManager.UpdateAsync(user);
            }
            else
            {
                userBodyInfo.Age = model.Age;
                userBodyInfo.Basin = model.Basin;
                userBodyInfo.Biceps = model.Biceps;
                userBodyInfo.Chest = model.Chest;
                userBodyInfo.FatRate = model.FatRate;
                userBodyInfo.Height = model.Height;
                userBodyInfo.InnerLegLength = model.InnerLegLength;
                userBodyInfo.OuterLegLength = model.OuterLegLength;
                userBodyInfo.ShoulderWidth = model.ShoulderWidth;
                userBodyInfo.Triceps = model.Triceps;
                userBodyInfo.Waist = model.Waist;
                userBodyInfo.Weight = model.Weight;

                _context.UserBodyInformations.Update(userBodyInfo);
                _context.SaveChanges();
            }
            TempData["UpdateSuccess"] = "Your profile has been successfully updated!";

            return RedirectToAction(nameof(Profile));
        }

        [HttpGet]
        public async Task<IActionResult> UserTrainerMatch(string trainerId, int[] trainingGoalIds)
        {
            if (string.IsNullOrWhiteSpace(trainerId))
                throw new Exception("Cannot found trainer!");

            var currentUser = await GetCurrentUserAsync();
            var trainer = await _userManager.FindByIdAsync(trainerId);

            var userTrainerMatch = new UserTrainerMatch
            {
                UserId = currentUser.Id,
                TrainerId = trainer.Id,
                UserTrainerMatchStatus = UserTrainerMatchStatus.Bargain,
                Created_Date = DateTime.Now
            };

            _context.UserTrainerMatchs.Add(userTrainerMatch);
            _context.SaveChanges();

            return RedirectToAction(nameof(UserTrainerMatchChat), new { userTrainerMatchId = userTrainerMatch.Id, trainingGoalIds = trainingGoalIds });
        }

        public async Task<IActionResult> UserTrainerMatchChat(int userTrainerMatchId, int[] trainingGoalIds)
        {
            var currentUser = await GetCurrentUserAsync();

            var userTrainerMatch = _context.UserTrainerMatchs.Include(x => x.UserTrainerMessages)
                                                             .Include(x => x.Trainer)
                                                                .ThenInclude(x => x.TrainerProfile)
                                                             .Include(x => x.Trainer)
                                                                .ThenInclude(x => x.UserCertificates)
                                                             .Single(x => x.Id == userTrainerMatchId);

            var trainingGoals = _context.TrainingGoal.Where(x => trainingGoalIds.Contains(x.Id)).ToList();

            var model = new UserTrainerMatchModel
            {
                UserTrainerMatch = userTrainerMatch,
                TrainingGoals = trainingGoals,
                CurrentUserId = currentUser.Id
            };

            return View(model);
        }

        public async Task<IActionResult> UserTrainerMatchChatForTrainer(int userTrainerMatchId, int[] trainingGoalIds)
        {
            var currentUser = await GetCurrentUserAsync();

            var userTrainerMatch = _context.UserTrainerMatchs.Include(x => x.UserTrainerMessages)
                                                             .Include(x => x.User)
                                                             .ThenInclude(x => x.UserBodyInformation)
                                                             .Single(x => x.Id == userTrainerMatchId);

            var trainingGoals = _context.TrainingGoal.Where(x => trainingGoalIds.Contains(x.Id)).ToList();

            var model = new UserTrainerMatchModel
            {
                UserTrainerMatch = userTrainerMatch,
                TrainingGoals = trainingGoals,
                CurrentUserId = currentUser.Id
            };

            return View(model);
        }

        [HttpPost]
        public async Task<IActionResult> SendMessage(int userTrainerMatchId, string message)
        {
            var user = await GetCurrentUserAsync();

            var userTrainerMatch = _context.UserTrainerMatchs.FirstOrDefault(x => x.Id == userTrainerMatchId);
            var userTrainingGoalIds = _context.UserTrainingGoal.Include(x => x.TrainingGoal).Where(x => x.HealthyUserId == user.Id).Select(x => x.TrainingGoalId).ToArray();

            var userTrainerMessage = new UserTrainerMessage
            {
                IsDealMessage = userTrainerMatch.UserTrainerMatchStatus == UserTrainerMatchStatus.Bargain,
                Created_Date = DateTime.Now,
                SenderId = user.Id,
                Message = message,
                UserTrainerMatchId = userTrainerMatchId
            };

            _context.UserTrainerMessages.Add(userTrainerMessage);
            _context.SaveChanges();

            return Json(new { redirectURL = Url.Action(nameof(UserTrainerMatchChat), "User", new { userTrainerMatchId = userTrainerMatch.Id, trainingGoalIds = userTrainingGoalIds }) });
        }
    }
}
