﻿using Healthy.Entities.Concrete.Identity;
using Healthy.Web.Concrete.Context;
using Healthy.Web.Models.Account;
using Microsoft.AspNetCore.Authorization;
using Microsoft.AspNetCore.Hosting;
using Microsoft.AspNetCore.Identity;
using Microsoft.AspNetCore.Mvc;
using Microsoft.EntityFrameworkCore;
using Newtonsoft.Json;
using System;
using System.Collections.Generic;
using System.IO;
using System.Linq;
using System.Threading.Tasks;

namespace Healthy.Web.Controllers
{
    [Authorize]
    public class AccountController : Controller
    {
        private readonly UserManager<HealthyUser> _userManager;
        private readonly SignInManager<HealthyUser> _signInManager;
        private readonly RoleManager<IdentityRole> _roleManager;
        private readonly HealthyContext _context;
        private readonly IWebHostEnvironment _webHostEnvironment;

        public AccountController(UserManager<HealthyUser> userManager, SignInManager<HealthyUser> signInManager, RoleManager<IdentityRole> roleManager, HealthyContext context, IWebHostEnvironment webHostEnvironment)
        {
            _userManager = userManager;
            _signInManager = signInManager;
            _roleManager = roleManager;
            _context = context;
            _webHostEnvironment = webHostEnvironment;
        }

        private Task<HealthyUser> GetCurrentUserAsync() => _userManager.GetUserAsync(HttpContext.User);

        [AllowAnonymous]
        public async Task<IActionResult> Home(int? userTrainerMatchFormId = null)
        {
            try
            {
                var user = await GetCurrentUserAsync();
                bool hasCurrentlyActiveMatch;

                if (user == null)
                {
                    hasCurrentlyActiveMatch = false;
                }
                else
                {
                    if (await _userManager.IsInRoleAsync(user, "trainer"))
                    {
                        var model = new HomeModel
                        {
                            CurrentTrainerCustomers = _context.UserTrainerMatchs.Where(x => x.TrainerId == user.Id)
                                                                                .Include(x => x.User)
                                                                                    .ThenInclude(x => x.UserBodyInformation)
                                                                                .Include(x => x.User)
                                                                                    .ThenInclude(x => x.UserTrainingGoals)
                                                                                .Include(x => x.User)
                                                                                    .ThenInclude(x => x.UserMatchs)
                                                                                .Select(x => x.User).ToList(),
                            TrainingGoals = _context.TrainingGoal.ToList(),
                            TrainerId = user.Id
                        };
                        return View(model);
                    }
                    hasCurrentlyActiveMatch = _context.UserTrainerMatchs.AsEnumerable().Any(x => x.UserId == user.Id && x.UserTrainerMatchStatus != UserTrainerMatchStatus.Rejected);
                }

                if (hasCurrentlyActiveMatch)
                {
                    var match = _context.UserTrainerMatchs.FirstOrDefault(x => x.UserId == user.Id);
                    var goals = _context.UserTrainingGoal.Where(x => x.HealthyUserId == user.Id).Select(x => x.TrainingGoal).ToList();
                    var model = new HomeModel
                    {
                        HasCurrentlyActiveMatch = true,
                        UserTrainerMatchId = match.Id,
                        SelectedTrainingGoals = goals,
                        TrainingGoals = _context.TrainingGoal.ToList()
                    };

                    return View(model);
                }
                if (userTrainerMatchFormId.HasValue)
                {
                    var userTrainerMatchForm = _context.UserTrainerMatchForm.FirstOrDefault(x => x.Id == userTrainerMatchFormId);
                    var userTrainingGoals = _context.UserTrainingGoal.Include(i => i.TrainingGoal).Where(x => x.HealthyUserId == user.Id).Select(x => x.TrainingGoal).ToList();

                    var foundTrainers = new List<HealthyUser>();
                    var trainers = await _userManager.GetUsersInRoleAsync("trainer");
                    foreach (var trainer in trainers)
                    {
                        var foundTrainer = _context.Users.Include(x => x.District).ThenInclude(x => x.Province).Include(x => x.TrainerProfile).Include(x => x.UserCertificates)
                                                          .Where(x => x.Id == trainer.Id &&
                                                                      x.TrainingEnvironment == userTrainerMatchForm.TrainingEnvironment &&
                                                                      x.DistrictId == userTrainerMatchForm.DistrictId).FirstOrDefault();
                        if (foundTrainer != null)
                            foundTrainers.Add(foundTrainer);
                    }
                    var model = new HomeModel
                    {
                        HasCurrentlyActiveMatch = hasCurrentlyActiveMatch,
                        TrainingGoals = _context.TrainingGoal.ToList(),
                        FoundTrainers = foundTrainers,
                        SelectedTrainingGoals = userTrainingGoals
                    };
                    return View(model);
                }
                else
                {
                    var model = new HomeModel
                    {
                        HasCurrentlyActiveMatch = hasCurrentlyActiveMatch,
                        TrainingGoals = _context.TrainingGoal.ToList(),
                        FoundTrainers = null
                    };
                    return View(model);
                }
            }
            catch (Exception e)
            {
                var model = new HomeModel
                {
                    HasCurrentlyActiveMatch = false
                };

                return View(model);
            }
        }

        [HttpGet]
        [AllowAnonymous]
        public IActionResult LocationJsonData()
        {
            var data = new List<LocationJsonData>();

            var provinces = _context.Provinces.Include(x => x.Districts).ToList();

            provinces.ForEach(province =>
            {
                province.Districts.ForEach(district =>
                {
                    var temp = new LocationJsonData
                    {
                        Value = district.Id,
                        Attributes = new LocationAttributeData
                        {
                            Province = province.Name,
                            District = district.Name,
                        }
                    };
                    data.Add(temp);

                });
            });
            var serialized = JsonConvert.SerializeObject(data);

            return Content(serialized, "application/json");
        }

        [HttpPost]
        public async Task<IActionResult> SearchTrainer(HomeModel model)
        {
            var user = await GetCurrentUserAsync();

            using (var transaction = _context.Database.BeginTransaction())
            {
                try
                {
                    var userMatchForm = new UserTrainerMatchForm
                    {
                        HealthyUserId = user.Id,
                        DistrictId = model.DistrictId,
                        TrainingEnvironment = (TrainingEnvironment)model.TrainingEnvironment
                    };

                    _context.UserTrainerMatchForm.Add(userMatchForm);
                    _context.SaveChanges();

                    var hasGoal = _context.UserTrainingGoal.Where(x => x.HealthyUserId == user.Id).Any();
                    if (hasGoal)
                    {
                        var goals = _context.UserTrainingGoal.Where(x => x.HealthyUserId == user.Id).ToList();
                        _context.UserTrainingGoal.RemoveRange(goals);
                        _context.SaveChanges();
                    }

                    foreach (int trainingGoalId in model.TraningGoalFilters)
                    {
                        var trainingGoal = _context.TrainingGoal.Single(x => x.Id == trainingGoalId);

                        var userTrainingGoal = new UserTrainingGoal
                        {
                            TrainingGoalId = trainingGoalId,
                            HealthyUserId = userMatchForm.HealthyUserId
                        };

                        _context.UserTrainingGoal.Add(userTrainingGoal);
                        _context.SaveChanges();
                    }

                    transaction.Commit();

                    return Json(new { redirectLocation = Url.Action(nameof(Home), new { userTrainerMatchFormId = userMatchForm.Id }) });
                }
                catch (Exception)
                {

                    throw;
                }
            }
        }


        [AllowAnonymous]
        public IActionResult RegisterAsCustomer()
        {
            return View(new RegisterModel());
        }

        [HttpPost]
        [AllowAnonymous]
        [ValidateAntiForgeryToken]
        public async Task<IActionResult> RegisterAsCustomer(RegisterModel model)
        {
            if (!ModelState.IsValid)
            {
                var returnModel = new RegisterModel
                {
                    Username = model.Username,
                    Name = model.Name,
                    Surname = model.Surname,
                    Email = model.Email,
                    PhoneNumber = model.PhoneNumber
                };
                return View(returnModel);
            }

            var userEmailExist = await _userManager.FindByEmailAsync(model.Email) == null;
            var userNameExists = await _userManager.FindByNameAsync(model.Username) == null;

            if (!userEmailExist)
            {
                ModelState.AddModelError("", "There is already an account registered with this email!");
                return View(model);
            }
            if (!userNameExists)
            {
                ModelState.AddModelError("", "This username is taken, please choose another one!");
                return View(model);
            }

            var customerRoleExist = await _roleManager.RoleExistsAsync("customer");
            if (!customerRoleExist)
            {
                var roleResult = await _roleManager.CreateAsync(new IdentityRole("customer"));
                if (!roleResult.Succeeded)
                    throw new Exception("Cannot create role : customer");
            }

            //TODO: Needs an email confirmer  to register and EmailConfirmed field should be false as default set.
            var newUser = new HealthyUser
            {
                UserName = model.Username,
                Name = model.Name,
                Surname = model.Surname,
                Email = model.Email,
                PhoneNumber = model.PhoneNumber,
                RegisterDate = DateTime.Now,
                EmailConfirmed = true,
                IsTrainer = false
            };


            var createUserResult = await _userManager.CreateAsync(newUser, model.Password);

            if (!createUserResult.Succeeded)
            {
                var errorMessage = string.Empty;
                foreach (var error in createUserResult.Errors)
                {
                    errorMessage += $"Code : {error.Code} Description : {error.Description} |";
                }
                ModelState.AddModelError("", errorMessage);
                return View(model);
            }

            var addToRolesResult = await _userManager.AddToRoleAsync(newUser, "customer");
            if (!addToRolesResult.Succeeded)
            {
                var errorMessage = string.Empty;
                foreach (var error in addToRolesResult.Errors)
                {
                    errorMessage += $"Code : {error.Code} Description : {error.Description} |";
                }
                ModelState.AddModelError("", errorMessage);
                return View(model);
            }

            TempData["RegisterSuccess"] = "You have successfully registered to Healthy!";

            return RedirectToAction(nameof(Login));
        }

        [AllowAnonymous]
        public IActionResult RegisterAsTrainer()
        {
            return View(new RegisterAsTrainerModel());
        }

        [HttpPost]
        [AllowAnonymous]
        [ValidateAntiForgeryToken]
        public async Task<IActionResult> RegisterAsTrainer(RegisterAsTrainerModel model)
        {
            if (!ModelState.IsValid)
            {
                var returnModel = new RegisterAsTrainerModel
                {
                    Username = model.Username,
                    Name = model.Name,
                    Surname = model.Surname,
                    Email = model.Email,
                    PhoneNumber = model.PhoneNumber,
                    TrainingEnvironment = model.TrainingEnvironment
                };
                return View(returnModel);
            }

            var userEmailExist = await _userManager.FindByEmailAsync(model.Email) == null;
            var userNameExists = await _userManager.FindByNameAsync(model.Username) == null;

            if (!userEmailExist)
            {
                ModelState.AddModelError("", "There is already an account registered with this email!");
                return View(model);
            }
            if (!userNameExists)
            {
                ModelState.AddModelError("", "This username is taken, please choose another one!");
                return View(model);
            }

            var customerRoleExist = await _roleManager.RoleExistsAsync("trainer");
            if (!customerRoleExist)
            {
                var roleResult = await _roleManager.CreateAsync(new IdentityRole("trainer"));
                if (!roleResult.Succeeded)
                    throw new Exception("Cannot create role : customer");
            }

            //TODO: Needs an email confirmer  to register and EmailConfirmed field should be false as default set.
            var newUser = new HealthyUser
            {
                UserName = model.Username,
                Name = model.Name,
                Surname = model.Surname,
                Email = model.Email,
                PhoneNumber = model.PhoneNumber,
                IsTrainer = true,
                RegisterDate = DateTime.Now,
                EmailConfirmed = true,
                TrainingEnvironment = (TrainingEnvironment)((int)model.TrainingEnvironment),
                DistrictId = model.DistrictId
            };


            var createUserResult = await _userManager.CreateAsync(newUser, model.Password);

            if (!createUserResult.Succeeded)
            {
                var errorMessage = string.Empty;
                foreach (var error in createUserResult.Errors)
                {
                    errorMessage += $"Code : {error.Code} Description : {error.Description} |";
                }
                ModelState.AddModelError("", errorMessage);
                return View(model);
            }

            var root = Path.Combine(_webHostEnvironment.WebRootPath, "usercertificates");
            if (!Directory.Exists(root))
                Directory.CreateDirectory(root);

            foreach (var certificate in model.Certificates)
            {
                var extension = Path.GetExtension(certificate.FileName);
                var fileName = Path.GetFileNameWithoutExtension(certificate.FileName);

                var fileUniqueName = fileName + "_" + Path.GetFileNameWithoutExtension(Path.GetRandomFileName()) + Path.GetFileNameWithoutExtension(Path.GetRandomFileName()) + extension;

                var path = Path.Combine(root, fileUniqueName);
                using var newCertificateFile = new FileStream(path, FileMode.Create);
                using var certificateFile = certificate.OpenReadStream();
                await certificateFile.CopyToAsync(newCertificateFile);

                var userCertificate = new UserCertificates
                {
                    HealthyUserId = newUser.Id,
                    FilePath = fileUniqueName
                };
                _context.UserCertificates.Add(userCertificate);
                _context.SaveChanges();
            }

            var addToRolesResult = await _userManager.AddToRoleAsync(newUser, "trainer");
            if (!addToRolesResult.Succeeded)
            {
                var errorMessage = string.Empty;
                foreach (var error in addToRolesResult.Errors)
                {
                    errorMessage += $"Code : {error.Code} Description : {error.Description} |";
                }
                ModelState.AddModelError("", errorMessage);
                return View(model);
            }

            TempData["RegisterSuccess"] = "You have successfully registered to Healthy!";

            return RedirectToAction(nameof(Login));
        }

        [AllowAnonymous]
        public IActionResult Login(string ReturnURL = null)
        {
            ViewBag.RegisterSuccess = TempData["RegisterSuccess"];

            if (User.Identity.IsAuthenticated)
            {
                return RedirectToAction(nameof(Home));
            }
            else
            {
                var model = new LoginModel
                {
                    ReturnURL = ReturnURL
                };
                return View(model);
            }
        }

        [HttpPost]
        [AllowAnonymous]
        [ValidateAntiForgeryToken]
        public async Task<IActionResult> Login(LoginModel model)
        {
            if (!ModelState.IsValid)
            {
                var returnModel = new LoginModel
                {
                    ReturnURL = model.ReturnURL
                };
                return View(returnModel);
            }
            var user = await _userManager.FindByEmailAsync(model.Email);

            if (user == null)
            {
                ModelState.AddModelError("", "Invalid Credentials.");
                return View(model);
            }

            var result = await _signInManager.PasswordSignInAsync(user, model.Password, true, false);

            if (!result.Succeeded)
            {
                ModelState.AddModelError("", "Invalid Credentials.");
                return View(model);
            }

            //TODO : Update Last_Login DateTime field of HealthyUser

            if (string.IsNullOrWhiteSpace(model.ReturnURL))
            {
                return RedirectToAction(nameof(Home));
            }
            else
            {
                return Redirect(model.ReturnURL);
            }

        }

        public async Task<IActionResult> Logout()
        {
            await _signInManager.SignOutAsync();
            return Redirect("~/");
        }

    }
}
