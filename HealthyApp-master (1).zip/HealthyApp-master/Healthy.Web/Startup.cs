using Healthy.Entities.Concrete.Identity;
using Healthy.Web.Concrete.Context;
using Healthy.Web.Data;
using Microsoft.AspNetCore.Builder;
using Microsoft.AspNetCore.Hosting;
using Microsoft.AspNetCore.Identity;
using Microsoft.EntityFrameworkCore;
using Microsoft.Extensions.Configuration;
using Microsoft.Extensions.DependencyInjection;
using Microsoft.Extensions.Hosting;
using System;

namespace Healthy.Web
{
    public class Startup
    {
        public IConfiguration Configuration { get; set; }

        public Startup(IConfiguration configuration)
        {
            Configuration = configuration;
        }

        public void ConfigureServices(IServiceCollection services)
        {
            services.AddDbContext<HealthyContext>(opts =>
                   opts.UseSqlServer(Configuration.GetConnectionString("HealthyConnection")));

            services.AddIdentity<HealthyUser, IdentityRole>()
            .AddEntityFrameworkStores<HealthyContext>()
            .AddDefaultTokenProviders();

            services.Configure<IdentityOptions>(options =>
            {
                options.Password.RequireDigit = true;
                options.Password.RequireLowercase = true;
                options.Password.RequiredLength = 8;
                options.Password.RequireNonAlphanumeric = false;
                options.Password.RequireUppercase = true;

                options.User.RequireUniqueEmail = true;
                options.SignIn.RequireConfirmedEmail = true;
                options.SignIn.RequireConfirmedPhoneNumber = false;
            });

            services.ConfigureApplicationCookie(options =>
            {
                // Cookie settings
                options.Cookie.HttpOnly = true;
                options.ExpireTimeSpan = TimeSpan.FromHours(2);
                options.LoginPath = "/account/login";
                options.LogoutPath = "/account/logout";
                options.AccessDeniedPath = "/account/accessdenied";
                options.SlidingExpiration = true;
                options.Cookie.Name = "Healthy.Cookie";
            });

            services.AddControllersWithViews();
            services.AddMvc();
        }

        // This method gets called by the runtime. Use this method to configure the HTTP request pipeline.
        public void Configure(IApplicationBuilder app, IWebHostEnvironment env, HealthyContext context, RoleManager<IdentityRole> roleManager, UserManager<HealthyUser> userManager)
        {
            if (env.IsDevelopment())
            {
                app.UseDeveloperExceptionPage();
                //SeedDatabase.CheckRolesCreateIfNotExist(roleManager).Wait();
                //SeedDatabase.CreateUser(userManager, "bkarakaya01@gmail.com", "bkarakaya01", "burak", "karakaya", "Healthy1234?").Wait();
                //SeedDatabase.CreateRoles(roleManager).Wait();
                //SeedDatabase.SeedLocation(context).Wait();
                //SeedDatabase.SeedUsers(context, userManager, env).Wait();
            }

            app.UseRouting();
            
            app.UseStaticFiles();

            app.UseAuthentication();

            app.UseAuthorization();

            app.UseEndpoints(endpoints =>
            {
                endpoints.MapControllerRoute("default", "{controller=Account}/{action=Home}");
            });
        }
    }
}
