﻿using Healthy.Entities.Abstract;
using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Healthy.Entities.Concrete.Identity
{
    public class UserCertificates : IEntity
    {
        public int Id { get; set; }
        
        public string HealthyUserId { get; set; }
        public HealthyUser HealthyUser { get; set; }

        public string CertificateName { get; set; }
        public string FilePath { get; set; }
    }
}
