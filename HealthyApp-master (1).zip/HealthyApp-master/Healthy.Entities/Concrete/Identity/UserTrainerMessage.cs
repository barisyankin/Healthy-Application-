﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Healthy.Entities.Concrete.Identity
{
    public class UserTrainerMessage
    {
        public int Id { get; set; }
        
        public int UserTrainerMatchId { get; set; }
        public UserTrainerMatch UserTrainerMatch { get; set; }
        
        public string SenderId { get; set; }
        public HealthyUser Sender { get; set; }

        public string Message { get; set; }
        public string File { get; set; }
        public bool IsDealMessage { get; set; }

        public DateTime Created_Date { get; set; }
    }
}
