﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Healthy.Entities.Concrete.Identity
{
    public class TrainerProfile
    {
        public int Id { get; set; }
        
        public string TrainerId { get; set; }
        public HealthyUser Trainer { get; set; }

        public string Title { get; set; }
        public string AboutMe { get; set; }
        
        public double PerLessonPrice { get; set; }
    }
}
