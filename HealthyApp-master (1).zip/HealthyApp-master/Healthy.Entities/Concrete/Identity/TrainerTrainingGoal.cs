﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Healthy.Entities.Concrete.Identity
{
    public class TrainerTrainingGoal
    {
        public string HealthyUserId { get; set; }
        public HealthyUser HealthyUser { get; set; }

        public int TrainingGoalId { get; set; }
        public TrainingGoal TrainingGoal { get; set; }
    }
}
