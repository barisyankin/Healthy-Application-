﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Healthy.Entities.Concrete.Identity
{
    public class TrainingGoal
    {
        public int Id { get; set; }
        public string Goal { get; set; }

        public List<UserTrainingGoal> UserTrainingGoals { get; set; }
        public List<TrainerTrainingGoal> TrainerTrainingGoals { get; set; }
    }
}
