﻿using Healthy.Entities.Abstract;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Healthy.Entities.Concrete.Identity
{
    public class UserBodyInformation : IEntity
    {
        public int Id { get; set; }

        public string HealthyUserId { get; set; }
        public HealthyUser HealthyUser { get; set; }

        public int Age { get; set; }

        public int Height { get; set; }
        public int Weight { get; set; }
        
        public int OuterLegLength { get; set; }
        public int InnerLegLength { get; set; }

        public int Chest { get; set; }
        public int Waist { get; set; }
        public int Basin { get; set; }

        public int ShoulderWidth { get; set; }

        public int Triceps { get; set; }
        public int Biceps { get; set; }

        public int FatRate { get; set; }
    }
}
