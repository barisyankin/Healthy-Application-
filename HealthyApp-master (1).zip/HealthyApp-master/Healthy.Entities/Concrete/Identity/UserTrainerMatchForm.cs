﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Healthy.Entities.Concrete.Identity
{
    public class UserTrainerMatchForm
    {
        public int Id { get; set; }

        public string HealthyUserId { get; set; }
        public HealthyUser HealthyUser { get; set; }

        public int DistrictId { get; set; }
        public District District { get; set; }

        public TrainingEnvironment TrainingEnvironment { get; set; }
    }

    public enum TrainingEnvironment
    {
        Online = 1,
        Hybrid = 2,
        FaceToFace = 3
    }
}
