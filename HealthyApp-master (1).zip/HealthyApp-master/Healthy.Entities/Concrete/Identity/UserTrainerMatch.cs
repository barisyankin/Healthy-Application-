﻿using Healthy.Entities.Abstract;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Healthy.Entities.Concrete.Identity
{
    public class UserTrainerMatch : IEntity
    {
        public int Id { get; set; }

        public string UserId { get; set; }
        public HealthyUser User { get; set; }

        public string TrainerId { get; set; }
        public HealthyUser Trainer { get; set; }

        public UserTrainerMatchStatus UserTrainerMatchStatus { get; set; }

        public DateTime? Created_Date { get; set; }
        public DateTime? Approved_Date { get; set; }

        public List<UserTrainerMessage> UserTrainerMessages { get; set; }
    }

    public enum UserTrainerMatchStatus
    {
        Bargain = 1,
        Approved = 2,
        Rejected = 3
    }
}
