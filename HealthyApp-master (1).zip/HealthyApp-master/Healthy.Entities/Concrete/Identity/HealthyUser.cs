﻿using Healthy.Entities.Abstract;
using Microsoft.AspNetCore.Identity;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Healthy.Entities.Concrete.Identity
{
    public class HealthyUser : IdentityUser, IEntity
    {
        public string Name { get; set; }
        public string Surname { get; set; }

        public bool IsTrainer { get; set; }
        public string Address1 { get; set; }
        
        public int? DistrictId { get; set; }
        public District District { get; set; }

        public int? TrainerProfileId { get; set; }
        public TrainerProfile TrainerProfile { get; set; }

        public int? UserBodyInformationId { get; set; }
        public UserBodyInformation UserBodyInformation { get; set; }

        /// <summary>
        /// For users in role Trainer
        /// </summary>
        public TrainingEnvironment? TrainingEnvironment { get; set; }

        public DateTime RegisterDate { get; set; }
        public DateTime? LastLogin { get; set; }
        public DateTime? Updated_Date { get; set; }
        public DateTime? Deleted_Date { get; set; }

        public List<UserCertificates> UserCertificates { get; set; }
        public List<UserTrainerMatch> UserMatchs { get; set; }
        public List<UserTrainerMatch> TrainerMatchs { get; set; }
        public List<UserTrainerMessage> UserTrainerMessages { get; set; }
        public List<UserTrainerMatchForm> UserTrainerMatchForms { get; set; }
        public List<TrainerTrainingGoal> TrainerTrainingGoals { get; set; }
        public List<UserTrainingGoal> UserTrainingGoals { get; set; }
    }
}
