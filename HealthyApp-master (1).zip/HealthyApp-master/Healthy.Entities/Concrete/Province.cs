﻿using Healthy.Entities.Abstract;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Healthy.Entities.Concrete
{
    public class Province : IEntity
    {
        public int Id { get; set; }
        public string Name { get; set; }

        public List<District> Districts { get; set; }
    }
}
