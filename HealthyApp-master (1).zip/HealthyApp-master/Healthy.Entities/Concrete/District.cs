﻿using Healthy.Entities.Abstract;
using Healthy.Entities.Concrete.Identity;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Healthy.Entities.Concrete
{
    public class District : IEntity
    {
        public int Id { get; set; }
        public string Name { get; set; }

        public int ProvinceId { get; set; }
        public Province Province { get; set; }

        public List<UserTrainerMatchForm> UserTrainerMatchForms { get; set; }
        public List<HealthyUser> HealthyUsers { get; set; }
    }
}
